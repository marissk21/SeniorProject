package bcs430w.utility;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.SortedList;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;


public class TableDialog extends Dialog<ObservableList> {

    public TableDialog(ObservableList<TableColumn> columns) {

        Group textGroup = new Group();
        Group textFieldGroup = new Group();
        for (int i = 0; i < columns.size() - 1; i++) {
            Text text = new Text(15, 15 + i * 25, columns.get(i).getText());
            textGroup.getChildren().add(text);
            TextField textField = new TextField();
            textField.setLayoutX(100);
            textField.setLayoutY(0 + i * 25);
            textFieldGroup.getChildren().add(textField);
        }

        Group group = new Group(textGroup, textFieldGroup);
        getDialogPane().setPrefWidth(250);
        getDialogPane().setPrefHeight(300);
        getDialogPane().setContent(group);

        getDialogPane().getButtonTypes().addAll(ButtonType.FINISH);
        setResultConverter(buttonType -> {
            ObservableList<String> list = FXCollections.observableArrayList();
            for (Node child : textFieldGroup.getChildren()) {
                TextField textField = (TextField)child;
                list.add(textField.getText());
            }
            return list;
        });

    }

    public TableDialog(ObservableList<TableColumn> columns, ObservableList row) {

        Group textGroup = new Group();
        Group textFieldGroup = new Group();
        for (int i = 0; i < columns.size() - 1; i++) {
            Text text = new Text(15, 15 + i * 25, columns.get(i).getText());
            textGroup.getChildren().add(text);
            TextField textField = new TextField();
            textField.setLayoutX(100);
            textField.setLayoutY(0 + i * 25);
            textField.setText(row.get(i).toString());
            textFieldGroup.getChildren().add(textField);
        }

        Group group = new Group(textGroup, textFieldGroup);
        getDialogPane().setPrefWidth(250);
        getDialogPane().setPrefHeight(300);
        getDialogPane().setContent(group);

        getDialogPane().getButtonTypes().addAll(ButtonType.FINISH);
        setResultConverter(buttonType -> {
            ObservableList<String> list = FXCollections.observableArrayList();
            for (Node child : textFieldGroup.getChildren()) {
                TextField textField = (TextField)child;
                list.add(textField.getText());
            }
            return list;
        });

    }

}

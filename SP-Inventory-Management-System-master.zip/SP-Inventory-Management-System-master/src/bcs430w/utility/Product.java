package bcs430w.utility;

public class Product {

    private int productID;
    private String productModelID;
    private float productPrice;
    private int productQuantity;

    public Product(int productID, String productModelID, float productPrice) {
        this.productID = productID;
        this.productModelID = productModelID;
        this.productPrice = productPrice;
        this.productQuantity = 1;
    }

    public Product(int productID, String productModelID, float productPrice, int productQuantity) {
        this.productID = productID;
        this.productModelID = productModelID;
        this.productPrice = productPrice;
        this.productQuantity = productQuantity;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductModelID() {
        return productModelID;
    }

    public void setProductModelID(String productModelID) {
        this.productModelID = productModelID;
    }

    public float getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(float productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductQuantity() {
        return productQuantity;
    }

    public void setProductQuantity(int productQuantity) {
        this.productQuantity = productQuantity;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productID=" + productID +
                ", productModelID='" + productModelID + '\'' +
                ", productPrice=" + productPrice +
                ", productQuantity=" + productQuantity +
                '}';
    }
}

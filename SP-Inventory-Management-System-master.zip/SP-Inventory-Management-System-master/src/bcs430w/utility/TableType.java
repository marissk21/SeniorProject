package bcs430w.utility;

public enum TableType {
    COMPANIES("Companies"),
    INVENTORY("Inventory"),
    ORDERLINE("OrderLine"),
    ORDERS("Orders"),
    PAYMENTS("Payments"),
    REVIEWS("Reviews"),
    USERS("users");

    private final String tableName;

    TableType(String tableName) {
        this.tableName = tableName;
    }

    public String getTableName() {
        return tableName;
    }

}

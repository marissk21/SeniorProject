package bcs430w.utility;

import javafx.scene.control.Alert;

import java.sql.*;

public class SQLDriver {

    private static Connection connection;

    public static Connection getConnection() {
        return connection;
    }

    public static Connection createConnection() {
        String dbHost = "107.180.24.242";
        String dbName = "bcs430w";
        String dbUser = "bcs430w";
        String dbPass = "w%26PmG%2AI%3D%7E9t%7E";


        try {
            connection = DriverManager.getConnection(
                    "jdbc:mysql://" + dbHost + "/" + dbName + "?user=" + dbUser + "&password=" + dbPass + "&sendStringParametersAsUnicode=false");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return connection;
    }

    public static ResultSet select(TableType tableType, String sqlParameters, Object... parameters) {
        PreparedStatement preparedStatement;
        try {
            preparedStatement = createConnection().prepareStatement("SELECT * from " + tableType.getTableName() + " " + sqlParameters);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            createConnection().close();
            return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ResultSet selectWithoutDisconnect(TableType tableType, String sqlParameters, Object... parameters) {
        PreparedStatement preparedStatement;
        try {
            preparedStatement = getConnection().prepareStatement("SELECT * from " + tableType.getTableName() + " " + sqlParameters);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }

            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ResultSet universal(String sqlParameters, Object... parameters) {
        PreparedStatement preparedStatement;
        try {
            preparedStatement = createConnection().prepareStatement(sqlParameters);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }
            ResultSet resultSet = preparedStatement.executeQuery();
            createConnection().close();
            return resultSet;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void universalUpdate(String sqlParameters, Object... parameters) {
        PreparedStatement preparedStatement;
        try {
            preparedStatement = createConnection().prepareStatement(sqlParameters);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }
            preparedStatement.executeUpdate();
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        try {
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static ResultSet insert(TableType tableType, String ifErrorMessage, String sqlParameters, Object... parameters) {
        try {
            PreparedStatement preparedStatement = createConnection().prepareStatement("INSERT INTO " + tableType.getTableName() + " " + sqlParameters, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }
            preparedStatement.executeUpdate();
            createConnection().close();
            return preparedStatement.getGeneratedKeys();
        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText(ifErrorMessage);
            alert.show();
            e.printStackTrace();
        }
        try {
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static ResultSet update(TableType tableType, String ifErrorMessage, String sqlParameters, Object... parameters) {
        try {
            PreparedStatement preparedStatement = createConnection().prepareStatement("UPDATE " + tableType.getTableName() + " SET " + sqlParameters, Statement.RETURN_GENERATED_KEYS);
            for (int i = 0; i < parameters.length; i++) {
                preparedStatement.setObject(i + 1, parameters[i]);
            }
            preparedStatement.executeUpdate();
            createConnection().close();
            return preparedStatement.getGeneratedKeys();
        } catch (SQLException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText(ifErrorMessage);
            alert.show();
            e.printStackTrace();
        }
        try {
            createConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void closeConnection(){
        try {
            getConnection().close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

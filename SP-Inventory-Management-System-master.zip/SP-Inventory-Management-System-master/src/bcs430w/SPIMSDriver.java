package bcs430w;

import bcs430w.utility.SQLDriver;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SPIMSDriver extends Application {

    private static Stage window;

    public static Stage getWindow() {
        return window;
    }

    @Override
    public void start(Stage primaryStage) throws Exception{
        window = primaryStage;
        primaryStage.setTitle("Whitman Tech - Inventory Management System");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(FXMLLoader.load(getClass().getResource("fxml/SPIMS.fxml"))));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}

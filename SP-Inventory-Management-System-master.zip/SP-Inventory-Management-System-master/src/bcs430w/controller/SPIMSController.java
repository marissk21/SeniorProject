package bcs430w.controller;

import bcs430w.SPIMSDriver;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.IOException;

public class SPIMSController {

    @FXML
    private ImageView logoImage;

    @FXML
    private Button loginBtn;

    @FXML
    private Button registerBtn;

    @FXML
    public void initialize() {
        logoImage.setImage(new Image(getClass().getResourceAsStream("logo.png")));
        RotateTransition rt = new RotateTransition(Duration.millis(10000), logoImage);
        rt.setAxis(Rotate.Y_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setInterpolator(Interpolator.LINEAR);
        rt.play();

        loginBtn.setOnAction(event -> {
            try {
                SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/Login.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        registerBtn.setOnAction(event -> {
            try {
                SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/Register.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

}

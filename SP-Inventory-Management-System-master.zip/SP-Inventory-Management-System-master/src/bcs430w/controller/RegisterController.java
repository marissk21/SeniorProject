package bcs430w.controller;

import bcs430w.SPIMSDriver;
import bcs430w.utility.SQLDriver;
import bcs430w.utility.TableType;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.regex.Pattern;

public class RegisterController {

    @FXML
    private ImageView logoImage;

    @FXML
    private TextField usernameTF;

    @FXML
    private TextField emailTF;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private PasswordField confirmPasswordTF;

    @FXML
    private Button registerBtn;

    @FXML
    private Button backBtn;

    @FXML
    private ImageView unValidationImg;

    @FXML
    private ImageView emailValidationImg;

    @FXML
    private ImageView pwValidationImg;

    @FXML
    private ImageView cpwValidationImg;

    //private BooleanBinding usernameDuplicateBinding = null;

    private boolean usernameValid = false;
    private boolean emailValid = false;
    private boolean passwordValid = false;
    private boolean confirmPasswordValid = false;


    @FXML
    public void initialize() {

        logoImage.setImage(new Image(getClass().getResourceAsStream("logo.png")));
        RotateTransition rt = new RotateTransition(Duration.millis(10000), logoImage);
        rt.setAxis(Rotate.Y_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setInterpolator(Interpolator.LINEAR);
        rt.play();

        //Validation Checking
        usernameTF.textProperty().addListener((observable, oldValue, newValue) -> {
            Task selectTask = new Task() {
                @Override
                protected Object call() throws Exception {
                    if (checkForDuplicateUsername()) {
                        unValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                        Tooltip.install(unValidationImg, new Tooltip("Username is already taken."));
                        usernameValid = false;
                    } else {
                        unValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                        Tooltip.install(unValidationImg, new Tooltip("Username is available."));
                        usernameValid = true;
                    }

                    if (usernameTF.getText().isEmpty()) {
                        unValidationImg.setImage(null);
                        Tooltip.install(unValidationImg, new Tooltip(""));
                        usernameValid = false;
                    }
                    return null;
                }
            };
            Thread thread = new Thread(selectTask);
            thread.start();
        });

        emailTF.textProperty().addListener((observable, oldValue, newValue) -> {
            Task selectTask = new Task() {
                @Override
                protected Object call() throws Exception {
                    if (!emailTF.getText().matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
                        emailValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                        Tooltip.install(unValidationImg, new Tooltip("Email is invalid"));
                        emailValid = false;
                    } else {
                        emailValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                        Tooltip.install(unValidationImg, new Tooltip("Email is valid"));
                        emailValid = true;
                    }

                    if (emailTF.getText().isEmpty()) {
                        emailValidationImg.setImage(null);
                        Tooltip.uninstall(unValidationImg, null);
                        emailValid = false;
                    }
                    return null;
                }
            };
            Thread thread = new Thread(selectTask);
            thread.start();
        });

        //^                 # start-of-string
        //(?=.*[0-9])       # a digit must occur at least once
        //(?=.*[a-z])       # a lower case letter must occur at least once
        //(?=.*[A-Z])       # an upper case letter must occur at least once
        //(?=.*[@#$%^&+=])  # a special character must occur at least once
        //(?=\S+$)          # no whitespace allowed in the entire string
        //.{8,}             # anything, at least eight places though
        //$                 # end-of-string


        // ^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\S+$).{8,}$
        passwordTF.textProperty().addListener((observable, oldValue, newValue) -> {
            Task selectTask = new Task() {
                @Override
                protected Object call() throws Exception {
                    if (!passwordTF.getText().matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$")) {
                        pwValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                        Tooltip.install(pwValidationImg, new Tooltip("Password is invalid"));
                        passwordValid = false;
                    } else {
                        pwValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                        Tooltip.install(pwValidationImg, new Tooltip("Password is valid"));
                        passwordValid = true;
                    }

                    if (passwordTF.getText().isEmpty()) {
                        pwValidationImg.setImage(null);
                        Tooltip.uninstall(pwValidationImg, null);
                        passwordValid = false;
                    }
                    return null;
                }
            };
            Thread thread = new Thread(selectTask);
            thread.start();
        });


        confirmPasswordTF.textProperty().addListener((observable, oldValue, newValue) -> {
            Task selectTask = new Task() {
                @Override
                protected Object call() throws Exception {
                    if (!confirmPasswordTF.getText().equals(passwordTF.getText())) {
                        cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                        Tooltip.install(cpwValidationImg, new Tooltip("Password does not match"));
                        confirmPasswordValid = false;
                    } else {
                        cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                        Tooltip.install(cpwValidationImg, new Tooltip("Password Matches"));
                        confirmPasswordValid = true;
                    }

                    if (confirmPasswordTF.getText().isEmpty()) {
                        cpwValidationImg.setImage(null);
                        Tooltip.uninstall(cpwValidationImg, null);
                        confirmPasswordValid = false;
                    }
                    return null;
                }
            };
            Thread thread = new Thread(selectTask);
            thread.start();
        });

        passwordTF.textProperty().addListener((observable, oldValue, newValue) -> {
            Task selectTask = new Task() {
                @Override
                protected Object call() throws Exception {
                    if (!confirmPasswordTF.getText().equals(passwordTF.getText())) {
                        cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                        Tooltip.install(cpwValidationImg, new Tooltip("Password does not match"));
                        passwordValid = false;
                    } else {
                        cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                        Tooltip.install(cpwValidationImg, new Tooltip("Password Matches"));
                        passwordValid = true;
                    }

                    if (confirmPasswordTF.getText().isEmpty()) {
                        cpwValidationImg.setImage(null);
                        Tooltip.uninstall(cpwValidationImg, null);
                        passwordValid = false;
                    }
                    return null;
                }
            };
            Thread thread = new Thread(selectTask);
            thread.start();
        });

        //Checks to see if the password text field and confirm password text field match
        BooleanBinding passwordMatchBinding = Bindings.equal(passwordTF.textProperty(), confirmPasswordTF.textProperty());
        passwordMatchBinding.addListener((observable, oldValue, newValue) -> {
            if (!confirmPasswordTF.getText().isEmpty()){
                if (observable.getValue()) {
                    cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("good.png")));
                    confirmPasswordValid = false;
                } else {
                    cpwValidationImg.setImage(new Image(getClass().getResourceAsStream("bad.png")));
                    confirmPasswordValid = true;
                }
        }
        });


        //Email Regex
        // ^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$

        registerBtn.setOnAction(event -> {
            String invalidResponse = "";

            if (!usernameValid) {
                invalidResponse += "\nUsername is Unavailable\n";
            }

            if (!emailValid) {
                invalidResponse += "\nEmail is Invalid\n";
            }

            if (!passwordValid) {
                invalidResponse += "\nPassword is missing required criteria:\n" +
                        "A digit must occur at least once\n" +
                        "A lower case letter must occur at least once\n" +
                        "An upper case letter must occur at least once\n" +
                        "A special character must occur at least once\n" +
                        "No whitespace allowed\n" +
                        "At least eight characters\n";
            }

            if (!confirmPasswordValid) {
                invalidResponse += "\nConfirm Password does not match Password\n";
            }


            if (invalidResponse.isEmpty()){
                try {
                    String salt1 = generateSalt().toString();
                    String salt2 = generateSalt().toString();
                    SQLDriver.insert(TableType.USERS, "Error creating user.", "(username, email, salt1, salt2, password) VALUES (?,?,?,?,?)", usernameTF.getText(), emailTF.getText(), salt1, salt2, generateHash(salt1 + passwordTF.getText() + salt2));

                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("Account Created Successfully");
                    alert.setContentText(usernameTF.getText() + ", your account has been successfully created. You will now be taken to the login page where you will use your newly created credentials to access your account.");
                    alert.show();
                    SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/Login.fxml"))));

                } catch (IOException e) {
                    e.printStackTrace();
                }
        }else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Criteria Not Sufficient");
                alert.setContentText(invalidResponse);
                alert.show();
                clearPasswordFields();
            }
        });

        backBtn.setTooltip(new Tooltip("Back To Main Menu"));
        backBtn.setOnAction(event -> {
            try {
                SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/SPIMS.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }

        });

    }

    public void clearPasswordFields() {
        passwordTF.clear();
        confirmPasswordTF.clear();
    }

    private static byte[] generateSalt() {
        byte[] s = new byte[10];
        new Random().nextBytes(s);
        return s;
    }

    // https://veerasundar.com/blog/2010/09/storing-passwords-in-java-web-application/
    private String generateHash(String input) {
        StringBuilder hash = new StringBuilder();
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] hashedBytes = sha.digest(input.getBytes());
            char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                    'a', 'b', 'c', 'd', 'e', 'f'};
            for (int idx = 0; idx < hashedBytes.length; idx++) {
                byte b = hashedBytes[idx];
                hash.append(digits[(b & 0xf0) >> 4]);
                hash.append(digits[b & 0x0f]);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        return hash.toString();
    }


    private boolean checkForDuplicateUsername() {
        try {

            //Todo change to prepare statement
            ResultSet resultSet = SQLDriver.select(TableType.USERS, "WHERE username = ?", usernameTF.getText());
            //ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM users WHERE username='" + usernameTF.getText() + "'");
            int count = 0;
            while (resultSet.next()) {
                count = resultSet.getInt(1);
            }
            if (count > 0) {
                return true;
            } else {

                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}

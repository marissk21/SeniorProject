package bcs430w.controller;

import bcs430w.SPIMSDriver;
import bcs430w.utility.SQLDriver;
import bcs430w.utility.TableType;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.beans.binding.BooleanBinding;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class LoginController {

    @FXML
    private ImageView logoImage;

    @FXML
    private TextField usernameTF;

    @FXML
    private PasswordField passwordTF;

    @FXML
    private Button loginBtn;

    @FXML
    private Button backBtn;

    public static Map<String, Object> userData = new HashMap<>();

    @FXML
    public void initialize() {

        logoImage.setImage(new Image(getClass().getResourceAsStream("logo.png")));
        RotateTransition rt = new RotateTransition(Duration.millis(10000), logoImage);
        rt.setAxis(Rotate.Y_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setInterpolator(Interpolator.LINEAR);
        rt.play();


        BooleanBinding booleanBinding = usernameTF.textProperty().isEmpty().or(passwordTF.textProperty().isEmpty());
        loginBtn.disableProperty().bind(booleanBinding);

        loginBtn.setOnAction(event -> {
            try {
                ResultSet resultSet = SQLDriver.select(TableType.USERS, "WHERE users.username = ?", usernameTF.getText());
                while (resultSet.next()) {
                    String token = generateHash(resultSet.getString("salt1") + passwordTF.getText() + resultSet.getString("salt2"));
                    if(token.equals(resultSet.getString("password"))){
                        userData.put("userID", resultSet.getInt("userID"));
                        userData.put("username", usernameTF.getText());
                        resultSet = SQLDriver.select(TableType.COMPANIES, "WHERE Companies.UserID = ?", userData.get("userID"));
                        if(resultSet.next()){
                            userData.put("companyID", resultSet.getInt("CompanyID"));
                            resultSet = SQLDriver.select(TableType.PAYMENTS, "WHERE Payments.companyID = ?", userData.get("companyID"));
                            if(resultSet.next()){
                                userData.put("paymentID", resultSet.getInt("paymentID"));
                            }
                        }

                        SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/MainMenu.fxml"))));
                        break;
                    }else {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Incorrect username and/or password");
                        alert.setContentText("The credentials that you have entered are incorrect, please try again.");
                        alert.show();

                        passwordTF.clear();
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        });

        backBtn.setTooltip(new Tooltip("Back To Main Menu"));
        backBtn.setOnAction(event -> {
            try {
                SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/SPIMS.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }

    private String generateHash(String input) {
        StringBuilder hash = new StringBuilder();
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] hashedBytes = sha.digest(input.getBytes());
            char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                    'a', 'b', 'c', 'd', 'e', 'f'};
            for (int idx = 0; idx < hashedBytes.length; idx++) {
                byte b = hashedBytes[idx];
                hash.append(digits[(b & 0xf0) >> 4]);
                hash.append(digits[b & 0x0f]);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hash.toString();
    }

}

package bcs430w.controller;

import bcs430w.SPIMSDriver;
import bcs430w.utility.Product;
import bcs430w.utility.SQLDriver;
import bcs430w.utility.TableDialog;
import bcs430w.utility.TableType;
import javafx.animation.Animation;
import javafx.animation.Interpolator;
import javafx.animation.RotateTransition;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.BooleanBinding;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.scene.transform.Rotate;
import javafx.stage.Window;
import javafx.util.Callback;
import javafx.util.Duration;
import javafx.util.StringConverter;

import java.io.IOException;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.sql.Date;
import java.text.NumberFormat;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class MainMenuController {

    @FXML
    private ImageView logoImage;

    @FXML
    private ScrollPane scrollPane;

    @FXML
    private ImageView potdImage;

    @FXML
    private Text potdText;

    @FXML
    private Text usernameTxt;

    @FXML
    private ListView<String> categoryList;

    @FXML
    private FlowPane productsPane;

    @FXML
    private Tab cartTab;

    @FXML
    private Text priceText;

    @FXML
    private Button orderBtn;

    @FXML
    private ScrollPane orderScrollPane;

    @FXML
    private FlowPane orderPane;

    @FXML
    private TableView<Product> cartTableView;

    @FXML
    private Button logoutBtn;

    @FXML
    private TextField currentPWTF;

    @FXML
    private TextField newPWTF;

    @FXML
    private TextField cNewPWTF;

    @FXML
    private Button updateBtn;

    @FXML
    private Tab ordersTab;

    @FXML
    private Pane comapnyInfo;

    @FXML
    private Text companyNameText;

    @FXML
    private Text companyAddressText;

    @FXML
    private Text companyCityText;

    @FXML
    private Text companyStateText;

    @FXML
    private Text companyZipCodeText;

    @FXML
    private Hyperlink editHyperlink;

    @FXML
    private Pane companyInfoEdit;

    @FXML
    private TextField companyNameTF;

    @FXML
    private TextField companyAddressTF;

    @FXML
    private TextField companyCityTF;

    @FXML
    private TextField companyZipCodeTF;

    @FXML
    private ComboBox<String> companyStateCB;

    @FXML
    private Hyperlink doneHyperlink;

    @FXML
    private Text ordersAmountText;

    @FXML
    private Text invoiceAmountText;

    @FXML
    private Pane paymentInfo;

    @FXML
    private Text ccNumText;

    @FXML
    private Text csvText;

    @FXML
    private Text experationText;

    @FXML
    private Text zipText;

    @FXML
    private Hyperlink editPaymentInfoHyperlink;

    @FXML
    private Pane paymentInfoEdit;

    @FXML
    private TextField ccNumTF;

    @FXML
    private TextField csvTF;

    @FXML
    private DatePicker experationDP;

    @FXML
    private TextField zipTF;

    @FXML
    private Hyperlink donePaymentInfoHyperlink;


    //Admin
    @FXML
    private Tab adminTab;

    @FXML
    private ComboBox<String> adminComboList;

    @FXML
    private TableView adminTableView;

    @FXML
    private Button adminAddBtn;

    @FXML
    private Button adminEditBtn;

    @FXML
    private Button adminDeleteBtn;

    private ObservableList data;


    @FXML
    public void initialize() {

        adminTableView.setEditable(false);

        ResultSet adminResultSet = SQLDriver.select(TableType.USERS, "WHERE `UserID` = ? AND isAdmin = ?", Integer.parseInt(LoginController.userData.get("userID").toString()), 1);
        try {
            adminResultSet.last();
            if (adminResultSet.getRow() == 1) {
                adminTab.setDisable(false);
            }

            ResultSet tablesResultSet = SQLDriver.universal("SELECT TABLE_NAME FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_TYPE = 'BASE TABLE' AND TABLE_SCHEMA='bcs430w'");
            while (tablesResultSet.next()) {
                adminComboList.getItems().add(tablesResultSet.getString("TABLE_NAME"));
            }


            adminComboList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                adminTableView.getColumns().clear();
                data = FXCollections.observableArrayList();
                ResultSet columnsResultSet = SQLDriver.universal("SELECT * FROM " + observable.getValue());
                try {


                    for (int i = 0; i < columnsResultSet.getMetaData().getColumnCount(); i++) {
                        final int j = i;
                        TableColumn column = new TableColumn<>(columnsResultSet.getMetaData().getColumnName(i + 1));
                        column.setCellValueFactory((Callback<TableColumn.CellDataFeatures<ObservableList, String>, ObservableValue<String>>) param -> {

                            try {
                                if (param.getValue().get(j) == null)
                                    return new SimpleStringProperty("");
                                return new SimpleStringProperty(param.getValue().get(j).toString());
                            }catch (ClassCastException e){

                            }
                            return null;

                        });
                        adminTableView.getColumns().add(column);
                    }

                    while (columnsResultSet.next()) {
                        ObservableList row = FXCollections.observableArrayList();
                        for (int i = 1; i <= columnsResultSet.getMetaData().getColumnCount(); i++) {
                            row.add(columnsResultSet.getString(i));
                        }
                        data.add(row);
                    }

                    adminTableView.setItems(data);

                } catch (SQLException e) {
                    e.printStackTrace();
                }

                adminTableView.getColumns().add(new TableColumn<>());
            });

            adminAddBtn.setOnAction(event -> {
                if(adminTableView.getItems().size() > 0){
                    TableDialog tableDialog = new TableDialog(adminTableView.getColumns());
                    Window tableDialogWindow = tableDialog.getDialogPane().getScene().getWindow();
                    tableDialogWindow.setOnCloseRequest(event1 -> tableDialogWindow.hide());
                    Optional<ObservableList> result = tableDialog.showAndWait();

                    if(result.isPresent()){
                            adminTableView.getItems().add(result.get());
                    }
                }
            });

            adminEditBtn.setOnAction(event -> {
                if(adminTableView.getItems().size() > 0){
                    TableDialog tableDialog = new TableDialog(adminTableView.getColumns(), (ObservableList)adminTableView.getSelectionModel().getSelectedItem());
                    Window tableDialogWindow = tableDialog.getDialogPane().getScene().getWindow();
                    tableDialogWindow.setOnCloseRequest(event1 -> tableDialogWindow.hide());
                    Optional<ObservableList> result = tableDialog.showAndWait();

                    if(result.isPresent()){
                        adminTableView.getItems().set(adminTableView.getSelectionModel().getSelectedIndex(), result.get());
                    }
                }
            });

            adminDeleteBtn.setOnAction(event -> {
                if(adminTableView.getItems().size() > 0){
                    SQLDriver.universalUpdate("DELETE FROM " + adminComboList.getSelectionModel().getSelectedItem() + " WHERE " + ((TableColumn)adminTableView.getColumns().get(0)).getText() + " = ?", ((ObservableList)adminTableView.getSelectionModel().getSelectedItem()).get(0));
                    adminTableView.getItems().remove(adminTableView.getSelectionModel().getSelectedIndex());
                }

                adminTableView.getSelectionModel().selectBelowCell();

            });

        } catch (SQLException e) {
            e.printStackTrace();
        }

        logoImage.setImage(new Image(getClass().getResourceAsStream("logo.png")));
        RotateTransition rt = new RotateTransition(Duration.millis(10000), logoImage);
        rt.setAxis(Rotate.Y_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setInterpolator(Interpolator.LINEAR);
        rt.play();

        usernameTxt.setText("Welcome, " + LoginController.userData.get("username").toString());

        try {
            ResultSet resultSet = SQLDriver.select(TableType.INVENTORY, "ORDER BY RAND()");
            resultSet.next();

            potdText.setText(resultSet.getString("ModelID"));

            try {
                URL productImageURL = new URL("https://www.mastefchief.com/bcs430w/images/" + resultSet.getString("Picture"));
                URLConnection urlConnection = productImageURL.openConnection();
                urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
                urlConnection.connect();
                potdImage.setImage(new Image(urlConnection.getInputStream()));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        TableColumn<Product, Integer> productIDColumn = new TableColumn<>("Product ID");
        productIDColumn.setCellValueFactory(new PropertyValueFactory<>("productID"));

        TableColumn<Product, String> productModelIDColumn = new TableColumn<>("Model");
        productModelIDColumn.setCellValueFactory(new PropertyValueFactory<>("productModelID"));

        TableColumn<Product, Float> productPriceColumn = new TableColumn<>("Price");
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("productPrice"));

        TableColumn productQuantityColumn = new TableColumn<>("Quantity");
        productQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("DUMMY"));
        productQuantityColumn.setPrefWidth(125);

        Callback<TableColumn<Product, String>, TableCell<Product, String>> quantityCellFactory
                = //
                new Callback<TableColumn<Product, String>, TableCell<Product, String>>() {
                    @Override
                    public TableCell call(final TableColumn<Product, String> param) {
                        final TableCell<Product, String> cell = new TableCell<Product, String>() {
                            final Spinner<Integer> quantitySpinner = new Spinner<>();

                            @Override
                            public void updateItem(String item, boolean empty) {
                                super.updateItem(item, empty);
                                if (empty) {
                                    setGraphic(null);
                                    setText(null);
                                } else {
                                    SpinnerValueFactory<Integer> valueFactory = null;
                                    try {
                                        ResultSet resultSet = SQLDriver.select(TableType.INVENTORY, "WHERE `ProductID` = ?", getTableView().getItems().get(0).getProductID());
                                        while (resultSet.next()) {
                                            valueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, resultSet.getInt("Quantity"));
                                        }
                                    } catch (SQLException e) {
                                        e.printStackTrace();
                                    }
                                    quantitySpinner.setValueFactory(valueFactory);
                                    quantitySpinner.setLayoutX(300);
                                    quantitySpinner.setLayoutY(70);
                                    quantitySpinner.setPrefWidth(50);

                                    quantitySpinner.getEditor().textProperty().addListener((observable, oldValue, newValue) -> {
                                        getTableView().getItems().get(getIndex()).setProductQuantity(quantitySpinner.getValue());
                                        float total = 0.0f;
                                        for (Product product : cartTableView.getItems()) {
                                            if (product.equals(getTableView().getItems().get(getIndex()))) {
                                                total += product.getProductPrice() * quantitySpinner.getValue();
                                            } else {
                                                total += product.getProductPrice();
                                            }
                                        }
                                        priceText.setText(NumberFormat.getCurrencyInstance().format(total));
                                    });

                                    setGraphic(quantitySpinner);
                                    setText(null);
                                }
                            }
                        };
                        cell.setStyle("-fx-alignment: CENTER;");
                        return cell;
                    }
                };
        productQuantityColumn.setCellFactory(quantityCellFactory);


        TableColumn removeProductColumn = new TableColumn("Remove Product");
        removeProductColumn.setPrefWidth(150);
        removeProductColumn.setCellValueFactory(new PropertyValueFactory<>("DUMMY"));

        Callback<TableColumn<Product, String>, TableCell<Product, String>> cellFactory
                = //
                new Callback<TableColumn<Product, String>, TableCell<Product, String>>() {
                    @Override
                    public TableCell call(final TableColumn<Product, String> param) {
                        final TableCell<Product, String> cell = new TableCell<Product, String>() {
                            final Button btn = new Button("Remove");

                            @Override
                            public void updateItem(String item, boolean empty) {
                                super.updateItem(item, empty);
                                if (empty) {
                                    setGraphic(null);
                                    setText(null);
                                } else {
                                    btn.setOnAction(event -> {
                                        getTableView().getItems().remove(getIndex());
                                        float total = 0.0f;
                                        for (Product product : cartTableView.getItems()) {
                                            total += product.getProductPrice();

                                        }
                                        priceText.setText(NumberFormat.getCurrencyInstance().format(total));
                                    });
                                    setGraphic(btn);
                                    setText(null);
                                }
                            }
                        };
                        cell.setStyle("-fx-alignment: CENTER;");
                        return cell;
                    }
                };
        removeProductColumn.setCellFactory(cellFactory);

        cartTableView.getColumns().setAll(productIDColumn, productModelIDColumn, productPriceColumn, productQuantityColumn, removeProductColumn);

        cartTab.setOnSelectionChanged(event -> {
            float total = 0.0f;
            for (Product item : cartTableView.getItems()) {
                total += item.getProductPrice();
            }
            priceText.setText(NumberFormat.getCurrencyInstance().format(total));

        });

        orderBtn.disableProperty().bind(Bindings.size(cartTableView.getItems()).isEqualTo(0));
        orderBtn.setOnAction(event -> {

            if (LoginController.userData.containsKey("companyID") && LoginController.userData.containsKey("paymentID")) {
                try {

                    //Create Order
                    ResultSet shipToResultSet = SQLDriver.select(TableType.COMPANIES, "WHERE `CompanyID` = ?", Integer.parseInt(LoginController.userData.get("companyID").toString()));
                    shipToResultSet.next();

                    ResultSet orderResultSet = SQLDriver.insert(TableType.ORDERS, "Unable to Prepare Order", "(`UserID`, `OrderStatus`, `PurchaseDate`, `ShipDate`, `ShipFrom`, `ShipTo`, `PaymentID`) VALUES (?,?,?,?,?,?,?)", LoginController.userData.get("userID"), "Invoice", new Date(Date.valueOf(LocalDate.now()).getTime()), null, "4200 Forest Avenue, New York, NY 10019", shipToResultSet.getString("Address") + ", " + shipToResultSet.getString("City") + ", " + shipToResultSet.getString("State") + " " + shipToResultSet.getInt("ZipCode"), Integer.parseInt(LoginController.userData.get("paymentID").toString()));

                    orderResultSet.next();

                    //Add orders items to order

                    for (Product product : cartTableView.getItems()) {
                        SQLDriver.insert(TableType.ORDERLINE, "Unable to prepare order items", "(`OrderID`, `ProductID`, `Quantity`, `Price`) VALUES (?,?,?,?)", orderResultSet.getInt(1), product.getProductID(), product.getProductQuantity(), product.getProductPrice());

                        SQLDriver.update(TableType.INVENTORY, "Unable to adjust inventory", "`Quantity` = `Quantity` - ? WHERE `Inventory`.`ProductID` = ?", product.getProductQuantity(), product.getProductID());
                    }

                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setTitle("");
                    alert.setHeaderText("Order Complete");
                    alert.setContentText("You have successfully submitted your order.");
                    alert.showAndWait();

                    cartTableView.getItems().clear();
                    priceText.setText("$0.00");

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Unable To Create Order");
                alert.setContentText("You must setup a company and a payment method in your account settings in order to create an order");
                alert.show();
            }
        });

        orderScrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        orderScrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);

        ordersTab.setOnSelectionChanged(event -> {
            orderPane.getChildren().clear();
            try {
                SQLDriver.createConnection();
                ResultSet resultSet = SQLDriver.selectWithoutDisconnect(TableType.ORDERS, "WHERE `UserID` = ? Order BY OrderID DESC", Integer.parseInt(LoginController.userData.get("userID").toString()));

                int count = 1;
                while (resultSet.next()) {
                    Pane pane = new Pane();
                    pane.setPrefWidth(orderPane.getWidth());
                    pane.setPrefHeight(100);
                    pane.setLayoutY(1 + count * 75);

                    if (count % 2 == 0) {
                        pane.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
                    } else {
                        pane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
                    }

                    Text orderID = new Text(0, 15, "Order ID: " + resultSet.getInt("OrderID"));

                    Hyperlink invoiceHyperlink = new Hyperlink("View Invoice");
                    invoiceHyperlink.setLayoutX(0);
                    invoiceHyperlink.setLayoutY(75);

                    String invoiceString = "ID: " + resultSet.getInt("OrderID")
                            + "\nPurchase Date: " + resultSet.getDate("PurchaseDate")
                            + (resultSet.getString("OrderStatus").equals("Shipped") ? "\nShipped Date: " + resultSet.getDate("ShipDate") : "")
                            + "\n\nShipped From: \n" + resultSet.getString("ShipFrom")
                            + "\n\nShipped To: \n" + resultSet.getString("ShipTo")
                            + "\n\nProducts: \n";

                    int itemsPurchased = 0;
                    ResultSet orderItemsResultSet = SQLDriver.selectWithoutDisconnect(TableType.ORDERLINE, "WHERE `OrderID` = ? ORDER BY `ProductID` ASC", resultSet.getInt("OrderID"));
                    float total = 0;
                    List<Product> reOrder = new ArrayList<>();
                    while (orderItemsResultSet.next()) {
                        ResultSet resultSet1 = SQLDriver.selectWithoutDisconnect(TableType.INVENTORY, "WHERE `ProductID` = ?", orderItemsResultSet.getInt("ProductID"));
                        resultSet1.next();
                        invoiceString += resultSet1.getString("ModelID") + " - $" + resultSet1.getFloat("Price") + " - " + orderItemsResultSet.getInt("Quantity") + "\n";
                        total += Float.parseFloat(String.format("%.02f", resultSet1.getFloat("Price") * orderItemsResultSet.getInt("Quantity")));
                        itemsPurchased++;
                        reOrder.add(new Product(orderItemsResultSet.getInt("ProductID"), resultSet1.getString("ModelID"), resultSet1.getFloat("Price"), orderItemsResultSet.getInt("Quantity")));
                    }

                    Hyperlink reOrderHyperlink = new Hyperlink("ReOrder");
                    reOrderHyperlink.setLayoutX(150);
                    reOrderHyperlink.setLayoutY(75);
                    reOrderHyperlink.setOnAction(event1 -> {
                        cartTableView.getItems().clear();
                        reOrder.forEach(product -> {
                            cartTableView.getItems().add(product);
                        });
                    });


                    invoiceString += "\n\n Total: $" + NumberFormat.getCurrencyInstance().format(total);

                    ButtonType payInvoice = new ButtonType("Pay Invoice", ButtonBar.ButtonData.OK_DONE);
                    ButtonType cancel = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
                    Alert invoiceAlert = new Alert(Alert.AlertType.INFORMATION, invoiceString, payInvoice, cancel);
                    invoiceAlert.setTitle("");
                    invoiceAlert.setHeaderText("Invoice");

                    int OrderID = resultSet.getInt("OrderID");
                    invoiceHyperlink.setOnAction(event1 -> {
                        Optional<ButtonType> result = invoiceAlert.showAndWait();

                        if (result.orElse(cancel) == payInvoice) {
                            Alert confirmPaymentAlert = new Alert(Alert.AlertType.CONFIRMATION);
                            confirmPaymentAlert.setTitle("");
                            confirmPaymentAlert.setHeaderText("Invoice Payment Successful");
                            confirmPaymentAlert.setContentText("You have successfully paid your order invoice. Your order will be shipped as soon as possible and should be recieved within 5-7 days.");
                            confirmPaymentAlert.show();

                            SQLDriver.update(TableType.ORDERS, "Cannot Pay Invoice", "`OrderStatus` = 'Shipped', `ShipDate` = ? WHERE `Orders`.`OrderID` = ?",
                                    new Date(Date.valueOf(LocalDate.now().plusDays(7)).getTime()), OrderID);

                        } else {
                            invoiceAlert.close();
                        }
                    });


                    if (resultSet.getString("OrderStatus").equals("Invoice")) {
                        invoiceHyperlink.setDisable(false);
                    } else {
                        invoiceHyperlink.setDisable(true);
                    }

                    Text itemsPurchasedText = new Text("Items Ordered: " + itemsPurchased);
                    itemsPurchasedText.setLayoutX(485);
                    itemsPurchasedText.setLayoutY(90);

                    Text datePurchaseText = new Text("Date Purchased: " + resultSet.getDate("PurchaseDate"));
                    datePurchaseText.setLayoutX(200);
                    datePurchaseText.setLayoutY(15);

                    Text totalPrice = new Text("Total: " + NumberFormat.getCurrencyInstance().format(total));
                    totalPrice.setLayoutX(500);
                    totalPrice.setLayoutY(15);


                    pane.getChildren().addAll(orderID, invoiceHyperlink, itemsPurchasedText, datePurchaseText, totalPrice, reOrderHyperlink);

                    orderPane.getChildren().add(pane);

                    count++;
                }
                SQLDriver.closeConnection();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        });


        categoryList.getItems().add("All");
        try {
            ResultSet resultSet = SQLDriver.universal("SELECT DISTINCT Category FROM `Inventory`");

            while (resultSet.next()) {
                categoryList.getItems().add(resultSet.getString("Category"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.ALWAYS);


        categoryList.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
            try {
                ResultSet resultSet;

                if (observable.getValue().equals("All")) {
                    resultSet = SQLDriver.select(TableType.INVENTORY, "ORDER BY ProductID");
                } else {
                    resultSet = SQLDriver.select(TableType.INVENTORY, "WHERE Category = ? ORDER BY ProductID", observable.getValue());
                }

                int count = 0;
                productsPane.getChildren().clear();
                scrollPane.setVvalue(0.0);

                while (resultSet.next()) {
                    Pane pane = new Pane();
                    pane.setPrefWidth(productsPane.getWidth());
                    pane.setPrefHeight(100);
                    pane.setLayoutY(1 + count * 75);

                    if (count % 2 == 0) {
                        pane.setBackground(new Background(new BackgroundFill(Color.WHITE, CornerRadii.EMPTY, Insets.EMPTY)));
                    } else {
                        pane.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, CornerRadii.EMPTY, Insets.EMPTY)));
                    }

                    //Product Image
                    ImageView productImage = new ImageView();
                    productImage.setX(15);
                    productImage.setY(15);
                    productImage.setFitWidth(75);
                    productImage.setFitHeight(75);
                    try {
                        URL productImageURL = new URL("https://www.mastefchief.com/bcs430w/images/" + resultSet.getString("Picture"));
                        URLConnection urlConnection = productImageURL.openConnection();
                        urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
                        urlConnection.connect();
                        productImage.setImage(new Image(urlConnection.getInputStream()));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                    //Product Identification Number
                    Text productID = new Text(0, 15, resultSet.getString("ProductID"));

                    //Product Model Number
                    Text productModel = new Text(100, 15, resultSet.getString("ModelID"));

                    Text brand = new Text(200, 15, resultSet.getString("Brand"));

                    Text supplier = new Text(300, 15, resultSet.getString("Supplier"));

                    Text price = new Text(100, 85, "$" + resultSet.getFloat("Price"));

                    Text description = new Text(resultSet.getString("Description"));
                    TextFlow descriptionTextFlow = new TextFlow(description);
                    descriptionTextFlow.setLayoutX(100);
                    descriptionTextFlow.setLayoutY(20);
                    descriptionTextFlow.setMaxWidth(300);


                    //Product Quantity Amount
                    Text outOfStockText = new Text(285, 85, "Out of Stock");
                    outOfStockText.setFill(Color.RED);

                    Button addButton = new Button("Add to Cart");
                    addButton.setLayoutX(360);
                    addButton.setLayoutY(70);
                    addButton.setOnAction(event -> {
                        Product product = new Product(Integer.parseInt(productID.getText()), productModel.getText(), Float.parseFloat(price.getText().replace("$", "")));
                        int dupCount = 0;
                        for (Product pr : cartTableView.getItems()) {
                            if(pr.getProductID() == product.getProductID())
                                dupCount++;
                        }
                        if(dupCount == 0){
                            cartTableView.getItems().add(product);
                        }

                    });
                    if (resultSet.getInt("Quantity") == 0) {
                        addButton.setDisable(true);
                    }

                    pane.getChildren().addAll(productImage, productID, productModel, descriptionTextFlow, price, (resultSet.getInt("Quantity") > 0 ? new Text(285, 85, "") : outOfStockText), supplier, brand, addButton);

                    productsPane.getChildren().add(pane);

                    count++;
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        Platform.runLater(() -> {
            categoryList.getSelectionModel().selectFirst();
        });

        //Profile Amount Info
        ResultSet orderAmountResultSet = SQLDriver.select(TableType.ORDERS, "WHERE `UserID` = ?", Integer.parseInt(LoginController.userData.get("userID").toString()));
        try {
            orderAmountResultSet.last();
            ordersAmountText.setText(String.valueOf(orderAmountResultSet.getRow()));
            orderAmountResultSet.beforeFirst();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        ResultSet invoiceAmountResultSet = SQLDriver.select(TableType.ORDERS, "WHERE `UserID` = ? AND `OrderStatus` = ?", Integer.parseInt(LoginController.userData.get("userID").toString()), "Invoice");
        try {
            invoiceAmountResultSet.last();
            invoiceAmountText.setText(String.valueOf(invoiceAmountResultSet.getRow()));
            invoiceAmountResultSet.beforeFirst();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        BooleanBinding nonEmptyFieldBinding = currentPWTF.textProperty().isEmpty().or(newPWTF.textProperty().isEmpty().or(cNewPWTF.textProperty().isEmpty()));
        updateBtn.disableProperty().bind(nonEmptyFieldBinding);

        updateBtn.setOnAction(event -> {
            String update = "";
            try {
                ResultSet resultSet = SQLDriver.select(TableType.USERS, "WHERE `UserID` = ?", Integer.parseInt(LoginController.userData.get("userID").toString()));
                resultSet.next();
                if (resultSet.getString("password").equals(generateHash(resultSet.getString("salt1") + currentPWTF.getText() + resultSet.getString("salt2")))) {
                    if (!newPWTF.getText().isEmpty() && !cNewPWTF.getText().isEmpty()) {
                        String salt1 = generateSalt().toString();
                        String salt2 = generateSalt().toString();
                        SQLDriver.update(TableType.USERS, "Unable to set new password", "`salt1` = ?, `salt2` = ? ,`password` = ? WHERE `users`.`UserID` = ?", salt1, salt2, generateHash(salt1 + newPWTF.getText() + salt2), Integer.parseInt(LoginController.userData.get("userID").toString()));
                        update += "Password Changed Successfully \n";
                    }
                }
            } catch (SQLException e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Error Changing Information");
                alert.setContentText(e.getMessage());
                alert.show();
                e.printStackTrace();
            }

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("");
            alert.setHeaderText("Change Successful");
            alert.setContentText(update);
            alert.showAndWait();
            currentPWTF.clear();
            newPWTF.clear();
            cNewPWTF.clear();
        });


        companyStateCB.getItems().addAll("AK", "AL", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY");
        companyStateCB.getSelectionModel().selectFirst();


        //Company Info
        try {
            ResultSet resultSet = SQLDriver.select(TableType.COMPANIES, "WHERE `CompanyID` = ?", Integer.parseInt(LoginController.userData.get("companyID").toString()));
            resultSet.next();
            comapnyInfo.setVisible(true);
            companyNameText.setText(resultSet.getString("CompanyName"));
            companyAddressText.setText(resultSet.getString("Address"));
            companyCityText.setText(resultSet.getString("City"));
            companyStateText.setText(resultSet.getString("State"));
            companyZipCodeText.setText(resultSet.getString("ZipCode"));
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            comapnyInfo.setVisible(false);
            companyInfoEdit.setVisible(true);
        }

        editHyperlink.setOnAction(event -> {
            comapnyInfo.setVisible(false);
            companyInfoEdit.setVisible(true);
            companyNameTF.setText(companyNameText.getText());
            companyAddressTF.setText(companyAddressText.getText());
            companyCityTF.setText(companyCityText.getText());
            companyStateCB.getSelectionModel().select(companyStateText.getText());
            companyZipCodeTF.setText(companyZipCodeText.getText());
        });

        doneHyperlink.setOnAction(event -> {
            try {
                PreparedStatement preparedStatement;
                if (LoginController.userData.containsKey("companyID")) {


                    ResultSet companyResultSet = SQLDriver.update(TableType.COMPANIES, "Unable to add company", "`CompanyName` = ?, `Address` = ?, `City` = ?, `State` = ?, `ZipCode` = ? WHERE `Companies`.`CompanyID` = ?", companyNameTF.getText(), companyAddressTF.getText(), companyCityTF.getText(), companyStateCB.getSelectionModel().getSelectedItem(), Integer.parseInt(companyZipCodeTF.getText()), Integer.parseInt(LoginController.userData.get("companyID").toString()));
                    companyResultSet.next();
                    if (!LoginController.userData.containsKey("companyID"))
                        LoginController.userData.put("companyID", companyResultSet.getString(1));

                } else {
                    ResultSet companyResultSet = SQLDriver.insert(TableType.COMPANIES, "Unable to add company", "(`UserID`, `CompanyName`, `Address`, `City`, `State`, `ZipCode`) VALUES (?,?,?,?,?,?)", Integer.parseInt(LoginController.userData.get("userID").toString()), companyNameTF.getText(), companyAddressTF.getText(), companyCityTF.getText(), companyStateCB.getSelectionModel().getSelectedItem(), Integer.parseInt(companyZipCodeTF.getText()));
                    companyResultSet.next();
                    if (!LoginController.userData.containsKey("companyID"))
                        LoginController.userData.put("companyID", companyResultSet.getString(1));
                }


                if (LoginController.userData.containsKey("companyID")) {
                    ResultSet resultSet = SQLDriver.select(TableType.COMPANIES, "WHERE `UserID` = ?", Integer.parseInt(LoginController.userData.get("userID").toString()));
                    while (resultSet.next()) {
                        LoginController.userData.put("companyID", resultSet.getString("CompanyID"));
                    }
                }

                companyNameText.setText(companyNameTF.getText());
                companyAddressText.setText(companyAddressTF.getText());
                companyCityText.setText(companyCityTF.getText());
                companyStateText.setText(companyStateCB.getSelectionModel().getSelectedItem());
                companyZipCodeText.setText(companyZipCodeTF.getText());

                companyInfoEdit.setVisible(false);
                comapnyInfo.setVisible(true);


            } catch (SQLException e) {
                e.printStackTrace();
            }
        });

        experationDP.setConverter(new StringConverter<LocalDate>() {
            @Override
            public String toString(LocalDate date) {
                if (date != null) {
                    try {
                        return DateTimeFormatter.ofPattern("yyyy-MM-dd").format(date);
                    } catch (DateTimeException e) {
                    }
                    System.out.println("Error with format");
                }
                return "";


            }

            @Override
            public LocalDate fromString(String string) {
                if (string != null && !string.isEmpty()) {
                    try {
                        return LocalDate.parse(string, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                    } catch (DateTimeParseException e) {
                    }

                    System.out.println("Error with parsing");
                }
                return null;

            }
        });


        //Payment Info
        try {
            ResultSet resultSet = SQLDriver.select(TableType.PAYMENTS, "WHERE `paymentID` = ?", ((int) LoginController.userData.get("paymentID")));
            resultSet.next();
            paymentInfo.setVisible(true);
            ccNumText.setText(resultSet.getString("credit_card_number"));
            csvText.setText(resultSet.getString("csvCode"));
            experationText.setText(resultSet.getString("expiration"));
            zipText.setText(resultSet.getString("zip_code"));
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            paymentInfo.setVisible(false);
            paymentInfoEdit.setVisible(true);
        }

        editPaymentInfoHyperlink.setOnAction(event -> {
            paymentInfo.setVisible(false);
            paymentInfoEdit.setVisible(true);
            ccNumTF.setText(ccNumText.getText());
            csvTF.setText(csvText.getText());
            experationDP.setValue(LocalDate.parse(experationText.getText(), DateTimeFormatter.ofPattern("yyyy-MM-dd")));
            zipTF.setText(zipText.getText());
        });

        donePaymentInfoHyperlink.setOnAction(event -> {
            try {
                if (LoginController.userData.containsKey("paymentID")) {
                    ResultSet paymentResultSet = SQLDriver.update(TableType.PAYMENTS, "Unable to add payment",
                            "`credit_card_number` = ?, `csvCode` = ?, `expiration` = ?, `zip_code` = ? WHERE `Payments`.`paymentID` = ?",
                            BigInteger.valueOf(Long.parseLong(ccNumTF.getText())), Integer.parseInt(csvTF.getText()),
                            new Date(experationDP.getValue().toEpochDay()), Integer.parseInt(zipTF.getText()), Integer.parseInt(LoginController.userData.get("paymentID").toString()));
                    paymentResultSet.next();
                    if (!LoginController.userData.containsKey("paymentID"))
                        LoginController.userData.put("paymentID", paymentResultSet.getString(1));
                } else {
                    ResultSet paymentResultSet = SQLDriver.insert(TableType.PAYMENTS, "Unable to add payment", "(`companyID`, `credit_card_number`, `csvCode`, `expiration`, `zip_code`) VALUES (?,?,?,?,?)", Integer.parseInt(LoginController.userData.get("companyID").toString()), BigInteger.valueOf(Long.parseLong(ccNumTF.getText())), Integer.parseInt(csvTF.getText()), new Date(experationDP.getValue().toEpochDay()), Integer.parseInt(zipTF.getText()));
                    paymentResultSet.next();
                    if (!LoginController.userData.containsKey("paymentID"))
                        LoginController.userData.put("paymentID", paymentResultSet.getString(1));
                }

                if (LoginController.userData.containsKey("paymentID")) {
                    ResultSet resultSet = SQLDriver.select(TableType.PAYMENTS, "WHERE `companyID` = ?", Integer.parseInt(LoginController.userData.get("companyID").toString()));
                    while (resultSet.next()) {
                        LoginController.userData.put("paymentID", resultSet.getString("paymentID"));
                    }
                }

                ccNumText.setText(ccNumTF.getText());
                csvText.setText(csvTF.getText());
                experationText.setText(experationDP.getValue().toString());
                zipText.setText(zipTF.getText());

                paymentInfoEdit.setVisible(false);
                paymentInfo.setVisible(true);


            } catch (SQLException e) {
                e.printStackTrace();
            }
        });


        logoutBtn.setOnAction(event -> {
            LoginController.userData.clear();
            try {
                SPIMSDriver.getWindow().setScene(new Scene(FXMLLoader.load(SPIMSDriver.class.getResource("fxml/Login.fxml"))));
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    public static byte[] generateSalt() {
        byte[] s = new byte[10];
        new Random().nextBytes(s);
        return s;
    }

    private String generateHash(String input) {
        StringBuilder hash = new StringBuilder();
        try {
            MessageDigest sha = MessageDigest.getInstance("SHA-1");
            byte[] hashedBytes = sha.digest(input.getBytes());
            char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                    'a', 'b', 'c', 'd', 'e', 'f'};
            for (int idx = 0; idx < hashedBytes.length; idx++) {
                byte b = hashedBytes[idx];
                hash.append(digits[(b & 0xf0) >> 4]);
                hash.append(digits[b & 0x0f]);
            }
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return hash.toString();
    }

}
